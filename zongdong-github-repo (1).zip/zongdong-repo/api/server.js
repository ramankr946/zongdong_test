// ─────────────────────────────────────────────────────────────────
//  ZongDong Backend API  –  server.js
//  Deploy to Google Cloud Run
//  Required env vars:
//    GCP_PROJECT_ID  = your GCP project id (e.g. zongdong-backend-123456)
//    ADMIN_SECRET    = a secret token you choose (e.g. "mysecret123")
//  The service-account key is handled automatically inside Cloud Run
//  when you give the Cloud Run service the BigQuery roles.
// ─────────────────────────────────────────────────────────────────
const express   = require('express');
const { BigQuery } = require('@google-cloud/bigquery');
const cors      = require('cors');

const app       = express();
const PROJECT   = process.env.GCP_PROJECT_ID || 'zongdong-backend';
const SECRET    = process.env.ADMIN_SECRET   || 'changeme';
const DATASET   = 'zongdong';
const bq        = new BigQuery({ projectId: PROJECT });

app.use(cors());
app.use(express.json());

// ── simple auth middleware ──
function auth(req, res, next) {
  const token = req.headers['x-admin-secret'];
  if (token !== SECRET) return res.status(401).json({ error: 'Unauthorized' });
  next();
}

function tbl(name) {
  return `\`${PROJECT}.${DATASET}.${name}\``;
}

// ════════════════════════════════════════
//  PRODUCTS
// ════════════════════════════════════════

// GET all products
app.get('/products', auth, async (req, res) => {
  try {
    const [rows] = await bq.query(
      `SELECT * FROM ${tbl('products')} ORDER BY created_at DESC LIMIT 2000`
    );
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST create product
app.post('/products', auth, async (req, res) => {
  try {
    const p = req.body;
    const row = {
      product_id:         'p_' + Date.now(),
      name:               p.name,
      brand:              p.brand || '',
      asin:               p.asin,
      category:           p.category || '',
      price_inr:          parseFloat(p.price_inr) || 0,
      original_price_inr: parseFloat(p.original_price_inr) || parseFloat(p.price_inr) || 0,
      weight_grams:       parseInt(p.weight_grams) || 500,
      stock_status:       p.stock_status || 'in',
      is_banned:          false,
      ban_reason:         null,
      emoji:              p.emoji || '📦',
      image_url:          p.image_url || null,
      description:        p.description || '',
      highlights:         JSON.stringify(p.highlights || []),
      tags:               (p.tags || []).join(','),
      custom_price_aed:   p.custom_price_aed ? parseFloat(p.custom_price_aed) : null,
      created_at:         bq.timestamp(new Date()),
      updated_at:         bq.timestamp(new Date()),
    };
    await bq.dataset(DATASET).table('products').insert([row]);
    res.json({ success: true, product_id: row.product_id });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// PUT update product
app.put('/products/:id', auth, async (req, res) => {
  try {
    const p = req.body;
    const fields = [];
    const params = { id: req.params.id };
    const allowed = ['name','brand','asin','category','price_inr','original_price_inr',
                     'weight_grams','stock_status','emoji','image_url','description',
                     'highlights','tags','custom_price_aed'];
    for (const k of allowed) {
      if (p[k] !== undefined) {
        fields.push(`${k} = @${k}`);
        params[k] = (k === 'highlights') ? JSON.stringify(p[k]) : p[k];
      }
    }
    if (!fields.length) return res.json({ success: true });
    await bq.query({
      query: `UPDATE ${tbl('products')} SET ${fields.join(', ')}, updated_at = CURRENT_TIMESTAMP() WHERE product_id = @id`,
      params
    });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// PATCH ban product
app.patch('/products/:id/ban', auth, async (req, res) => {
  try {
    await bq.query({
      query: `UPDATE ${tbl('products')} SET is_banned = TRUE, ban_reason = @reason, updated_at = CURRENT_TIMESTAMP() WHERE product_id = @id`,
      params: { reason: req.body.reason || '', id: req.params.id }
    });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// PATCH unban product
app.patch('/products/:id/unban', auth, async (req, res) => {
  try {
    await bq.query({
      query: `UPDATE ${tbl('products')} SET is_banned = FALSE, ban_reason = NULL, updated_at = CURRENT_TIMESTAMP() WHERE product_id = @id`,
      params: { id: req.params.id }
    });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// PATCH stock status
app.patch('/products/:id/stock', auth, async (req, res) => {
  try {
    await bq.query({
      query: `UPDATE ${tbl('products')} SET stock_status = @status, updated_at = CURRENT_TIMESTAMP() WHERE product_id = @id`,
      params: { status: req.body.status, id: req.params.id }
    });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ════════════════════════════════════════
//  ORDERS
// ════════════════════════════════════════

// GET all orders
app.get('/orders', auth, async (req, res) => {
  try {
    const [rows] = await bq.query(
      `SELECT * FROM ${tbl('orders')} ORDER BY order_date DESC, updated_at DESC LIMIT 1000`
    );
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST create order
app.post('/orders', auth, async (req, res) => {
  try {
    const o = req.body;
    const row = {
      order_id:         'ZD-' + Math.floor(1000 + Math.random() * 9000),
      customer_name:    o.customer_name,
      customer_email:   o.customer_email || '',
      customer_phone:   o.customer_phone || '',
      delivery_address: o.delivery_address || '',
      product_name:     o.product_name,
      product_emoji:    o.product_emoji || '📦',
      product_asin:     o.product_asin || '',
      amount_aed:       parseFloat(o.amount_aed) || 0,
      status:           'pending',
      tracking_number:  '',
      notes:            o.notes || '',
      order_date:       bq.date(new Date()),
      updated_at:       bq.timestamp(new Date()),
    };
    await bq.dataset(DATASET).table('orders').insert([row]);
    res.json({ success: true, order_id: row.order_id });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// PATCH update order status + tracking
app.patch('/orders/:id', auth, async (req, res) => {
  try {
    const fields = [];
    const params = { id: req.params.id };
    if (req.body.status !== undefined)          { fields.push('status = @status');                     params.status   = req.body.status; }
    if (req.body.tracking_number !== undefined) { fields.push('tracking_number = @tracking_number');  params.tracking_number = req.body.tracking_number; }
    if (req.body.notes !== undefined)           { fields.push('notes = @notes');                       params.notes    = req.body.notes; }
    if (!fields.length) return res.json({ success: true });
    await bq.query({
      query: `UPDATE ${tbl('orders')} SET ${fields.join(', ')}, updated_at = CURRENT_TIMESTAMP() WHERE order_id = @id`,
      params
    });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ════════════════════════════════════════
//  PRICING OVERRIDES
// ════════════════════════════════════════

// GET all overrides
app.get('/pricing', auth, async (req, res) => {
  try {
    const [rows] = await bq.query(
      `SELECT * FROM ${tbl('pricing_overrides')} ORDER BY set_at DESC`
    );
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST / upsert price override
app.post('/pricing', auth, async (req, res) => {
  try {
    const { product_id, custom_price_aed, override_reason } = req.body;
    // Delete existing then insert (BQ doesn't support UPSERT easily)
    await bq.query({
      query: `DELETE FROM ${tbl('pricing_overrides')} WHERE product_id = @id`,
      params: { id: product_id }
    });
    if (custom_price_aed !== null && custom_price_aed !== undefined) {
      await bq.dataset(DATASET).table('pricing_overrides').insert([{
        product_id,
        custom_price_aed: parseFloat(custom_price_aed),
        override_reason:  override_reason || '',
        set_by:           'admin',
        set_at:           bq.timestamp(new Date()),
        expires_at:       null,
      }]);
    }
    res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ════════════════════════════════════════
//  STATS  (dashboard overview)
// ════════════════════════════════════════
app.get('/stats', auth, async (req, res) => {
  try {
    const [[prodRows], [orderRows]] = await Promise.all([
      bq.query(`SELECT COUNT(*) as total,
                COUNTIF(is_banned=FALSE AND stock_status='in') as active,
                COUNTIF(stock_status='out') as out_of_stock,
                COUNTIF(is_banned=TRUE) as banned
                FROM ${tbl('products')}`),
      bq.query(`SELECT COUNT(*) as total,
                COUNTIF(status='pending') as pending,
                COUNTIF(status='ordered') as ordered,
                COUNTIF(status='shipped') as shipped,
                COUNTIF(status='delivered') as delivered,
                SUM(IF(status != 'cancelled', amount_aed, 0)) as revenue
                FROM ${tbl('orders')}`)
    ]);
    res.json({ products: prodRows[0], orders: orderRows[0] });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// health check
app.get('/', (req, res) => res.json({ status: 'ok', service: 'ZongDong API' }));

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`ZongDong API listening on port ${PORT}`));
