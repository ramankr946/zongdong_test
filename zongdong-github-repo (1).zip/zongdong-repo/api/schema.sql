-- ══════════════════════════════════════════════════════
--  ZongDong BigQuery Schema
--  Run each block in BigQuery Query Editor
--  Replace YOUR_PROJECT_ID with your actual GCP project id
-- ══════════════════════════════════════════════════════

-- Step 1: Create dataset (run in Cloud Shell or Console)
-- bq mk --dataset --location=US YOUR_PROJECT_ID:zongdong

-- ── TABLE 1: products ──────────────────────────────────
CREATE TABLE IF NOT EXISTS `YOUR_PROJECT_ID.zongdong.products`
(
  product_id          STRING    NOT NULL,
  name                STRING    NOT NULL,
  brand               STRING,
  asin                STRING    NOT NULL,
  category            STRING,
  price_inr           FLOAT64   NOT NULL,
  original_price_inr  FLOAT64,
  weight_grams        INT64     DEFAULT 500,
  stock_status        STRING    DEFAULT 'in',
  is_banned           BOOL      DEFAULT FALSE,
  ban_reason          STRING,
  emoji               STRING,
  image_url           STRING,
  description         STRING,
  highlights          STRING,
  tags                STRING,
  custom_price_aed    FLOAT64,
  created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP(),
  updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

-- ── TABLE 2: orders ────────────────────────────────────
CREATE TABLE IF NOT EXISTS `YOUR_PROJECT_ID.zongdong.orders`
(
  order_id            STRING    NOT NULL,
  customer_name       STRING    NOT NULL,
  customer_email      STRING,
  customer_phone      STRING,
  delivery_address    STRING,
  product_name        STRING    NOT NULL,
  product_emoji       STRING,
  product_asin        STRING,
  amount_aed          FLOAT64,
  status              STRING    DEFAULT 'pending',
  tracking_number     STRING,
  notes               STRING,
  order_date          DATE      DEFAULT CURRENT_DATE(),
  updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

-- ── TABLE 3: pricing_overrides ─────────────────────────
CREATE TABLE IF NOT EXISTS `YOUR_PROJECT_ID.zongdong.pricing_overrides`
(
  product_id          STRING    NOT NULL,
  custom_price_aed    FLOAT64   NOT NULL,
  override_reason     STRING,
  set_by              STRING    DEFAULT 'admin',
  set_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP(),
  expires_at          TIMESTAMP
);

-- ── Verify all 3 tables were created ───────────────────
SELECT table_name, creation_time, row_count
FROM `YOUR_PROJECT_ID.zongdong.INFORMATION_SCHEMA.TABLES`
ORDER BY table_name;
