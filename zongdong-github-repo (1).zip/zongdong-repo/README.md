# 🪔 ZongDong — Operations Platform

Cross-border e-commerce backend: Amazon India → UAE delivery.  
Full stack: **Node.js API** on Cloud Run + **BigQuery** database + **GitHub Pages** frontend.

---

## 🔗 Live URLs (after setup)

| Tool | URL |
|------|-----|
| Operations Hub | `https://YOUR_USERNAME.github.io/zongdong/` |
| Admin Dashboard | `https://YOUR_USERNAME.github.io/zongdong/dashboard/` |
| Import Hub | `https://YOUR_USERNAME.github.io/zongdong/importers/` |
| Cloud Run API | `https://zongdong-api-673989170541.us-central1.run.app` |
| BigQuery Console | `https://console.cloud.google.com/bigquery?project=zongdong-backend` |

---

## 📁 Repo Structure

```
zongdong/
├── index.html                    # Operations hub landing page
├── dashboard/
│   └── index.html                # Admin dashboard (products, orders, pricing)
├── importers/
│   ├── index.html                # Import hub landing page
│   ├── import-products.html      # Bulk upload → products table
│   ├── import-orders.html        # Bulk upload → orders table
│   └── import-pricing.html       # Bulk upload → pricing_overrides table
├── api/
│   ├── server.js                 # Node.js Express API
│   ├── package.json              # Dependencies
│   ├── Dockerfile                # Cloud Run container
│   └── schema.sql                # BigQuery table schemas
└── .github/
    └── workflows/
        ├── deploy-api.yml        # Auto-deploy API to Cloud Run on push
        └── deploy-pages.yml      # Auto-deploy frontend to GitHub Pages on push
```

---

## 🚀 Setup Guide

### 1. Create GitHub Repo

```bash
# On GitHub: Create new repo named "zongdong" (public for free Pages)
git clone https://github.com/YOUR_USERNAME/zongdong.git
cd zongdong
# Copy all files from this package into the folder
git add .
git commit -m "Initial ZongDong deployment"
git push origin main
```

### 2. Enable GitHub Pages

1. Go to your repo → **Settings** → **Pages**
2. Source: **GitHub Actions**
3. The `deploy-pages.yml` workflow runs automatically on push

### 3. Add GitHub Secrets (for auto-deploy of API)

Go to repo → **Settings** → **Secrets and variables** → **Actions** → **New repository secret**

| Secret Name | Value |
|-------------|-------|
| `GCP_SA_KEY` | Contents of your service account JSON key file |
| `GCP_PROJECT_ID` | `zongdong-backend` |
| `ADMIN_SECRET` | `Sallo@1212` (or your chosen secret) |

### 4. Get your Service Account JSON for GCP_SA_KEY

```bash
# In Google Cloud Console → IAM → Service Accounts
# Click your service account → Keys → Add Key → JSON
# Open the downloaded file, copy ALL contents → paste as GCP_SA_KEY secret
```

### 5. First Deploy

Push any change to `api/` folder → GitHub Actions auto-deploys to Cloud Run.  
Push any change to `dashboard/` or `importers/` → GitHub Actions auto-deploys to Pages.

---

## 🗄️ BigQuery Tables

| Table | Purpose |
|-------|---------|
| `zongdong.products` | Product catalog with pricing, stock, ASIN |
| `zongdong.orders` | Customer orders with tracking |
| `zongdong.pricing_overrides` | Manual AED price overrides |

Run `api/schema.sql` in BigQuery console to create tables.

---

## 💰 Pricing Formula

```
base_AED     = price_inr × 0.044
logistics    = max(weight_grams, 500) / 1000 × 16 AED/kg
margin       = min((base + logistics) × 10%, 20 AED)
vat          = (base + logistics + margin) × 5%
final_price  = base + logistics + margin + vat
```

---

## 🔌 API Endpoints

All endpoints require header: `x-admin-secret: YOUR_SECRET`

| Method | Path | Description |
|--------|------|-------------|
| GET | `/` | Health check |
| GET | `/products` | List all products |
| POST | `/products` | Create product |
| PUT | `/products/:id` | Update product |
| PATCH | `/products/:id/ban` | Ban product |
| PATCH | `/products/:id/unban` | Unban product |
| GET | `/orders` | List all orders |
| POST | `/orders` | Create order |
| PATCH | `/orders/:id` | Update status/tracking |
| GET | `/pricing` | List price overrides |
| POST | `/pricing` | Set/update price override |
| GET | `/stats` | Dashboard stats summary |

---

## 🔄 Auto-Deploy Triggers

| What changes | What deploys |
|--------------|-------------|
| Any file in `api/` | Cloud Run API redeploys |
| Any file in `dashboard/` or `importers/` | GitHub Pages redeploys |

---

## 💡 Cost Estimate

| Service | Monthly Cost |
|---------|-------------|
| BigQuery | ~$0 (free tier: 10GB storage, 1TB queries) |
| Cloud Run | ~$0 (free tier: 2M requests/month) |
| GitHub Pages | Free |
| **Total** | **~$0/month** |
